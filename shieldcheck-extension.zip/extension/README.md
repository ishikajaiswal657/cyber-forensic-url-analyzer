# ShieldCheck Browser Extension

Wraps your existing ShieldCheck API (deployed on Railway) in a Chrome/Edge and
Firefox extension. No scanning logic runs in the browser — WHOIS, SSL, and
geolocation checks still happen server-side, exactly as they do on the website.

## Features
- **This Tab** — auto-scans the active tab's URL as soon as you open the popup.
- **Check URL** — paste any URL to scan manually.
- **Right-click → "Scan this link with ShieldCheck"** — scan any link on a page
  without opening it. Result badges the toolbar icon (OK / SUS / RISK) and
  fires a notification; full details land in the "Last Link Scan" tab.

## 1. Backend change required (one-time)
Browser extensions can't call an API that doesn't allow their origin. The
updated `app.py` + `requirements.txt` I've also given you add `flask-cors`
so `/api/*` accepts requests from `chrome-extension://` and `moz-extension://`
origins. Redeploy those two files to Railway before testing the extension.

## 2. Load in Chrome / Edge
1. Go to `chrome://extensions` (or `edge://extensions`).
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this `extension/` folder as-is
   (it already uses `manifest.json`, the Chrome/Edge manifest).

## 3. Load in Firefox
1. Rename `manifest.json` → `manifest.chrome.json` and
   `manifest.firefox.json` → `manifest.json` (Firefox only reads
   `manifest.json`; keep a copy of the Chrome one for later).
2. Go to `about:debugging#/runtime/this-firefox`.
3. Click **Load Temporary Add-on** and select `manifest.json` inside this
   folder.
4. Temporary add-ons are removed on browser restart — for a permanent
   install you'll need to sign it via
   [addons.mozilla.org](https://addons.mozilla.org/developers/) (free) or
   self-distribute as an unsigned add-on via Firefox Developer/Nightly.

## 4. Publish (optional, later)
- **Chrome Web Store**: zip this folder, $5 one-time developer fee, submit
  at the Chrome Web Store Developer Dashboard.
- **Firefox Add-ons (AMO)**: zip this folder (with the Firefox manifest as
  `manifest.json`), submit at addons.mozilla.org — free, and Mozilla signs
  it for you automatically.

## Notes
- Icons are auto-generated placeholders (`icons/`) — swap them for your own
  branding any time; sizes 16/32/48/128 are all that's referenced.
- The API base URL is set once, at the top of `background.js` and
  `popup.js` — update both if you ever move off Railway.
- Email (`.eml`) scanning still lives on the website only; the extension
  currently focuses on URL scanning, since browsers don't give extensions
  an easy way to hand over an arbitrary local file for that endpoint.

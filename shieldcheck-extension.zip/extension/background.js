// ShieldCheck background script — shared between Chrome (service_worker)
// and Firefox (background.scripts). Only uses callback-style chrome.* APIs
// so it runs unmodified on both.

const API_BASE = "https://cyber-forensic-url-analyzer-production.up.railway.app";
const MENU_ID = "shieldcheck-scan-link";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: 'Scan this link with ShieldCheck',
    contexts: ["link"]
  });
});

function setBadge(text, color) {
  if (chrome.action && chrome.action.setBadgeText) {
    chrome.action.setBadgeText({ text });
    chrome.action.setBadgeBackgroundColor({ color });
  }
}

function badgeForVerdict(verdict) {
  if (verdict === "HIGH RISK / PHISHING LIKELY") return ["RISK", "#dc2626"];
  if (verdict === "SUSPICIOUS") return ["SUS", "#d97706"];
  if (verdict === "LIKELY SAFE") return ["OK", "#16a34a"];
  return ["", "#6b7280"];
}

async function scanUrl(url) {
  const resp = await fetch(`${API_BASE}/api/check-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url })
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.error || `Request failed (${resp.status})`);
  }
  return resp.json();
}

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== MENU_ID || !info.linkUrl) return;

  setBadge("...", "#0f766e");
  try {
    const result = await scanUrl(info.linkUrl);
    await chrome.storage.local.set({
      lastResult: result,
      lastResultSource: "context-menu",
      lastResultTime: Date.now()
    });

    const [badgeText, badgeColor] = badgeForVerdict(result.verdict);
    setBadge(badgeText, badgeColor);

    if (chrome.notifications) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: `ShieldCheck: ${result.verdict}`,
        message: `${result.domain}\nRisk score: ${result.score}\nClick the toolbar icon for full details.`
      });
    }
  } catch (e) {
    setBadge("ERR", "#6b7280");
    if (chrome.notifications) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: "ShieldCheck scan failed",
        message: String(e.message || e)
      });
    }
  }
});

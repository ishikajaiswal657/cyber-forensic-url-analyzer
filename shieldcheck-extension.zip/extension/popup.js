const API_BASE = "https://cyber-forensic-url-analyzer-production.up.railway.app";

// ---------- tab switching ----------
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add("active");
  });
});

// ---------- shared helpers ----------
async function scanUrl(url) {
  const resp = await fetch(`${API_BASE}/api/check-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url })
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.error || `Request failed (${resp.status})`);
  return data;
}

function verdictClass(verdict) {
  if (verdict === "HIGH RISK / PHISHING LIKELY") return "verdict-risk";
  if (verdict === "SUSPICIOUS") return "verdict-suspicious";
  if (verdict === "LIKELY SAFE") return "verdict-safe";
  return "";
}

function verdictIcon(verdict) {
  if (verdict === "HIGH RISK / PHISHING LIKELY") return "🚨";
  if (verdict === "SUSPICIOUS") return "⚠️";
  if (verdict === "LIKELY SAFE") return "✅";
  return "";
}

function renderResult(container, result) {
  const geo = result.geo || {};
  const vt = result.vt_result;
  let vtLine = "Unavailable (no API key or rate limit)";
  if (vt && vt.status === "success") {
    const total = (vt.malicious || 0) + (vt.suspicious || 0) + (vt.harmless || 0) + (vt.undetected || 0);
    vtLine = `${vt.malicious} malicious / ${vt.suspicious} suspicious / ${vt.harmless} clean (of ${total})`;
  } else if (vt && vt.status === "failed") {
    vtLine = "Scan failed (domain offline/unreachable)";
  }

  container.innerHTML = `
    <span class="verdict-badge ${verdictClass(result.verdict)}">
      ${verdictIcon(result.verdict)} ${result.verdict}
    </span>
    <table class="result-table">
      <tr><td class="label">URL</td><td class="value">${escapeHtml(result.url)}</td></tr>
      <tr><td class="label">Domain</td><td class="value">${escapeHtml(result.domain)}</td></tr>
      <tr><td class="label">Created</td><td class="value">${result.created_date ? escapeHtml(String(result.created_date)) : "N/A"} (${result.age_days ?? "Unknown"} days ago)</td></tr>
      <tr><td class="label">SSL</td><td class="value">${escapeHtml(String(result.ssl_issuer))}</td></tr>
      <tr><td class="label">Server</td><td class="value">${escapeHtml(geo.ip || "N/A")} ${geo.isp ? "(" + escapeHtml(geo.isp) + ")" : ""}</td></tr>
      <tr><td class="label">Location</td><td class="value">${escapeHtml(geo.city || "N/A")}, ${escapeHtml(geo.country || "N/A")}</td></tr>
      <tr><td class="label">VirusTotal</td><td class="value">${escapeHtml(vtLine)}</td></tr>
      <tr><td class="label">Risk score</td><td class="value"><strong>${result.score}</strong></td></tr>
    </table>
  `;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function showLoading(container) {
  container.innerHTML = `<div class="loading">Scanning…</div>`;
}

function showError(container, msg) {
  container.innerHTML = `<div class="error">⚠️ ${escapeHtml(msg)}</div>`;
}

// ---------- "This Tab" panel: auto-scans the active tab on popup open ----------
const currentUrlEl = document.getElementById("currentUrl");
const currentResultEl = document.getElementById("currentResult");
const scanCurrentBtn = document.getElementById("scanCurrentBtn");

let activeTabUrl = null;

function scanCurrentTab() {
  if (!activeTabUrl) return;
  showLoading(currentResultEl);
  scanUrl(activeTabUrl)
    .then(result => renderResult(currentResultEl, result))
    .catch(err => showError(currentResultEl, err.message));
}

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs && tabs[0];
  if (!tab || !tab.url || !/^https?:\/\//.test(tab.url)) {
    currentUrlEl.textContent = "No scannable URL on this tab.";
    scanCurrentBtn.disabled = true;
    return;
  }
  activeTabUrl = tab.url;
  currentUrlEl.textContent = activeTabUrl;
  scanCurrentTab(); // auto-scan on popup open
});

scanCurrentBtn.addEventListener("click", scanCurrentTab);

// ---------- "Check URL" panel: manual paste-and-scan ----------
const manualUrlEl = document.getElementById("manualUrl");
const manualResultEl = document.getElementById("manualResult");
const manualScanBtn = document.getElementById("manualScanBtn");

function runManualScan() {
  const url = manualUrlEl.value.trim();
  if (!url) return;
  showLoading(manualResultEl);
  scanUrl(url)
    .then(result => renderResult(manualResultEl, result))
    .catch(err => showError(manualResultEl, err.message));
}

manualScanBtn.addEventListener("click", runManualScan);
manualUrlEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") runManualScan();
});

// ---------- "Last Link Scan" panel: populated by the right-click context menu ----------
const lastResultEl = document.getElementById("lastResult");

chrome.storage.local.get(["lastResult", "lastResultTime"], (data) => {
  if (data.lastResult) {
    renderResult(lastResultEl, data.lastResult);
  } else {
    lastResultEl.innerHTML = `<div class="loading">No link scanned yet.</div>`;
  }
});

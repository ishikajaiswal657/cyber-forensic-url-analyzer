# ShieldCheck Browser Extension

Wraps your existing ShieldCheck API (deployed on Render) in a Chrome/Edge and
Firefox extension. No scanning logic runs in the browser — WHOIS, SSL, and
geolocation checks still happen server-side, exactly as they do on the website.

## Features
- **Real-time guard** — scans every page you navigate to in the background.
  If a page comes back SUSPICIOUS or HIGH RISK, the tab is redirected to a
  warning screen before it can load. Nothing is ever blocked silently —
  you always choose "Take me to safety" or "Continue anyway." Toggle this
  on/off from the switch at the top of the popup (on by default).
- **This Tab** — auto-scans the active tab's URL as soon as you open the popup.
- **Check URL** — paste any URL to scan manually.
- **Check Email** — upload a saved `.eml` file to check headers, SPF/DKIM/DMARC,
  urgency language, dangerous attachments, and every link found in the body
  (each link is scanned the same way as "Check URL").
- **Right-click → "Scan this link with ShieldCheck"** — scan any link on a page
  without opening it. Result badges the toolbar icon (OK / SUS / RISK) and
  fires a notification; full details land in the "Last Link Scan" tab.

## 1. Backend change required (one-time)
Browser extensions can't call an API that doesn't allow their origin. Make
sure your Flask backend (now on Render at
`https://shieldcheck-gih5.onrender.com`) has `flask-cors` enabled so
`/api/*` accepts requests from `chrome-extension://` and `moz-extension://`
origins.

## 2. Load in Chrome / Edge
1. Go to `chrome://extensions` (or `edge://extensions`).
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this `extension/` folder as-is
   (it already uses `manifest.json`, the Chrome/Edge manifest).

## 3. Load in Firefox
1. Rename `manifest.json` → `manifest.chrome.json` and
   `manifest.firefox.json` → `manifest.json` (Firefox only reads
   `manifest.json`; keep a copy of the Chrome one for later).
2. Go to `about:debugging#/runtime/this-firefox`.
3. Click **Load Temporary Add-on** and select `manifest.json` inside this
   folder.
4. Temporary add-ons are removed on browser restart — for a permanent
   install you'll need to sign it via
   [addons.mozilla.org](https://addons.mozilla.org/developers/) (free) or
   self-distribute as an unsigned add-on via Firefox Developer/Nightly.

## 4. Publish (optional, later)
- **Chrome Web Store**: zip this folder, $5 one-time developer fee, submit
  at the Chrome Web Store Developer Dashboard.
- **Firefox Add-ons (AMO)**: zip this folder (with the Firefox manifest as
  `manifest.json`), submit at addons.mozilla.org — free, and Mozilla signs
  it for you automatically.

## How the real-time guard works
- Listens for top-level navigations (`webNavigation.onBeforeNavigate`), skips
  iframes/ads, and fires off a scan for the destination URL.
- The page starts loading normally while the scan runs in the background —
  MV3 extensions can't synchronously block navigation the way old blocking
  `webRequest` could. If the verdict comes back risky, the tab is redirected
  to `warning.html` (usually within a second or two).
- "Take me to safety" goes back in tab history (or to Google if there's
  nowhere to go); "Continue anyway" re-navigates to the original URL and
  whitelists that exact URL for one navigation so it isn't re-scanned in a loop.
- Scan results are cached in memory for 5 minutes per URL to avoid hammering
  the API on repeat visits.
- If the API call fails or times out, the guard fails **open** (lets the page
  load) rather than blocking on an error.
- Requires the `webNavigation` and `tabs` permissions, added in this update.

## Notes
- Icons are auto-generated placeholders (`icons/`) — swap them for your own
  branding any time; sizes 16/32/48/128 are all that's referenced.
- The API base URL is set once, at the top of `background.js` and
  `popup.js` (currently `https://shieldcheck-gih5.onrender.com`) — update
  both, plus `host_permissions` in each manifest file, if you ever move
  hosts again.

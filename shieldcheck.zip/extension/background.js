// ShieldCheck background script — shared between Chrome (service_worker)
// and Firefox (background.scripts). Only uses callback-style chrome.* APIs
// so it runs unmodified on both.

const API_BASE = "https://shieldcheck-gih5.onrender.com";
const MENU_ID = "shieldcheck-scan-link";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: 'Scan this link with ShieldCheck',
    contexts: ["link"]
  });
});

// ---------- scan history (all scans, from any source) ----------
const MAX_HISTORY = 100;

function addToHistory(entry) {
  chrome.storage.local.get({ scanHistory: [] }, (data) => {
    const history = [entry, ...data.scanHistory].slice(0, MAX_HISTORY);
    chrome.storage.local.set({ scanHistory: history });
  });
}

function historyEntryFromResult(result, source) {
  return {
    url: result.url,
    domain: result.domain || "",
    verdict: result.verdict,
    score: result.score,
    source,
    time: Date.now()
  };
}

function setBadge(text, color) {
  if (chrome.action && chrome.action.setBadgeText) {
    chrome.action.setBadgeText({ text });
    chrome.action.setBadgeBackgroundColor({ color });
  }
}

function badgeForVerdict(verdict) {
  if (verdict === "HIGH RISK / PHISHING LIKELY") return ["RISK", "#dc2626"];
  if (verdict === "SUSPICIOUS") return ["SUS", "#d97706"];
  if (verdict === "LIKELY SAFE") return ["OK", "#16a34a"];
  return ["", "#6b7280"];
}

async function scanUrl(url) {
  const resp = await fetch(`${API_BASE}/api/check-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url })
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.error || `Request failed (${resp.status})`);
  }
  return resp.json();
}

// ---------- real-time navigation guard ----------
// Scans every top-level http(s) navigation. If the verdict comes back
// SUSPICIOUS or HIGH RISK, the tab is redirected to warning.html instead
// of letting the page load further. The user always has to choose
// "Continue anyway" or "Go back" — nothing is auto-blocked silently and
// nothing is auto-allowed silently.

const RISKY_VERDICTS = new Set(["HIGH RISK / PHISHING LIKELY", "SUSPICIOUS"]);
const CACHE_TTL_MS = 5 * 60 * 1000; // don't re-hit the API for the same URL within 5 min
const scanCache = new Map(); // url -> { result, time }
const allowedOnce = new Set(); // urls the user just approved via the warning page

let realtimeGuardEnabled = true;
chrome.storage.local.get({ realtimeGuard: true }, (data) => {
  realtimeGuardEnabled = data.realtimeGuard;
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && "realtimeGuard" in changes) {
    realtimeGuardEnabled = changes.realtimeGuard.newValue;
  }
});

function isExtensionUrl(url) {
  return url.startsWith(chrome.runtime.getURL(""));
}

async function getScanResult(url) {
  const cached = scanCache.get(url);
  if (cached && Date.now() - cached.time < CACHE_TTL_MS) return cached.result;
  const result = await scanUrl(url);
  scanCache.set(url, { result, time: Date.now() });
  return result;
}

async function checkAndMaybeWarn(tabId, url) {
  let result;
  try {
    result = await getScanResult(url);
  } catch (e) {
    return; // fail open — never block a page just because the API/network hiccuped
  }
  addToHistory(historyEntryFromResult(result, "realtime-guard"));
  if (RISKY_VERDICTS.has(result.verdict)) {
    const warningUrl = chrome.runtime.getURL("warning.html") + "?" +
      new URLSearchParams({
        url,
        verdict: result.verdict,
        score: String(result.score),
        domain: result.domain || ""
      }).toString();
    chrome.tabs.update(tabId, { url: warningUrl }).catch(() => {});
  }
}

if (chrome.webNavigation && chrome.webNavigation.onBeforeNavigate) {
  chrome.webNavigation.onBeforeNavigate.addListener((details) => {
    if (!realtimeGuardEnabled) return;
    if (details.frameId !== 0) return; // main frame only, skip iframes/ads
    const url = details.url;
    if (!/^https?:\/\//.test(url)) return;
    if (isExtensionUrl(url)) return;
    if (allowedOnce.has(url)) {
      allowedOnce.delete(url); // one-time bypass consumed
      return;
    }
    checkAndMaybeWarn(details.tabId, url);
  });
}

// Warning page tells us the user chose "Continue anyway"
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message && message.type === "shieldcheck-allow-and-navigate" && message.url && sender.tab) {
    allowedOnce.add(message.url);
    chrome.tabs.update(sender.tab.id, { url: message.url }).catch(() => {});
  }
});

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== MENU_ID || !info.linkUrl) return;

  setBadge("...", "#0f766e");
  try {
    const result = await scanUrl(info.linkUrl);
    addToHistory(historyEntryFromResult(result, "context-menu"));

    const [badgeText, badgeColor] = badgeForVerdict(result.verdict);
    setBadge(badgeText, badgeColor);

    if (chrome.notifications) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: `ShieldCheck: ${result.verdict}`,
        message: `${result.domain}\nRisk score: ${result.score}\nClick the toolbar icon for full details.`
      });
    }
  } catch (e) {
    setBadge("ERR", "#6b7280");
    if (chrome.notifications) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: "ShieldCheck scan failed",
        message: String(e.message || e)
      });
    }
  }
});

const API_BASE = "https://shieldcheck-gih5.onrender.com";

// ---------- real-time guard toggle ----------
const guardToggle = document.getElementById("guardToggle");
chrome.storage.local.get({ realtimeGuard: true }, (data) => {
  guardToggle.checked = data.realtimeGuard;
});
guardToggle.addEventListener("change", () => {
  chrome.storage.local.set({ realtimeGuard: guardToggle.checked });
});

// ---------- tab switching ----------
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add("active");
  });
});

// ---------- shared helpers ----------
async function scanUrl(url) {
  const resp = await fetch(`${API_BASE}/api/check-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url })
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.error || `Request failed (${resp.status})`);
  return data;
}

function verdictClass(verdict) {
  if (verdict === "HIGH RISK / PHISHING LIKELY") return "verdict-risk";
  if (verdict === "SUSPICIOUS") return "verdict-suspicious";
  if (verdict === "LIKELY SAFE" || verdict === "LIKELY LEGITIMATE") return "verdict-safe";
  return "";
}

function verdictIcon(verdict) {
  if (verdict === "HIGH RISK / PHISHING LIKELY") return "🚨";
  if (verdict === "SUSPICIOUS") return "⚠️";
  if (verdict === "LIKELY SAFE" || verdict === "LIKELY LEGITIMATE") return "✅";
  return "";
}

function renderResult(container, result) {
  const geo = result.geo || {};
  const vt = result.vt_result;
  let vtLine = "Unavailable (no API key or rate limit)";
  if (vt && vt.status === "success") {
    const total = (vt.malicious || 0) + (vt.suspicious || 0) + (vt.harmless || 0) + (vt.undetected || 0);
    vtLine = `${vt.malicious} malicious / ${vt.suspicious} suspicious / ${vt.harmless} clean (of ${total})`;
  } else if (vt && vt.status === "failed") {
    vtLine = "Scan failed (domain offline/unreachable)";
  }

  container.innerHTML = `
    <span class="verdict-badge ${verdictClass(result.verdict)}">
      ${verdictIcon(result.verdict)} ${result.verdict}
    </span>
    <table class="result-table">
      <tr><td class="label">URL</td><td class="value">${escapeHtml(result.url)}</td></tr>
      <tr><td class="label">Domain</td><td class="value">${escapeHtml(result.domain)}</td></tr>
      <tr><td class="label">Created</td><td class="value">${result.created_date ? escapeHtml(String(result.created_date)) : "N/A"} (${result.age_days ?? "Unknown"} days ago)</td></tr>
      <tr><td class="label">SSL</td><td class="value">${escapeHtml(String(result.ssl_issuer))}</td></tr>
      <tr><td class="label">Server</td><td class="value">${escapeHtml(geo.ip || "N/A")} ${geo.isp ? "(" + escapeHtml(geo.isp) + ")" : ""}</td></tr>
      <tr><td class="label">Location</td><td class="value">${escapeHtml(geo.city || "N/A")}, ${escapeHtml(geo.country || "N/A")}</td></tr>
      <tr><td class="label">VirusTotal</td><td class="value">${escapeHtml(vtLine)}</td></tr>
      <tr><td class="label">Risk score</td><td class="value"><strong>${result.score}</strong></td></tr>
    </table>
  `;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function showLoading(container) {
  container.innerHTML = `<div class="loading">Scanning…</div>`;
}

function showError(container, msg) {
  container.innerHTML = `<div class="error">⚠️ ${escapeHtml(msg)}</div>`;
}

// ---------- scan history (shared with background.js's own writes) ----------
const MAX_HISTORY = 100;

function addToHistory(entry) {
  chrome.storage.local.get({ scanHistory: [] }, (data) => {
    const history = [entry, ...data.scanHistory].slice(0, MAX_HISTORY);
    chrome.storage.local.set({ scanHistory: history });
  });
}

function historyEntryFromResult(result, source) {
  return {
    url: result.url,
    domain: result.domain || "",
    verdict: result.verdict,
    score: result.score,
    source,
    time: Date.now()
  };
}

// ---------- "This Tab" panel: auto-scans the active tab on popup open ----------
const currentUrlEl = document.getElementById("currentUrl");
const currentResultEl = document.getElementById("currentResult");
const scanCurrentBtn = document.getElementById("scanCurrentBtn");

let activeTabUrl = null;

function scanCurrentTab() {
  if (!activeTabUrl) return;
  showLoading(currentResultEl);
  scanUrl(activeTabUrl)
    .then(result => {
      renderResult(currentResultEl, result);
      addToHistory(historyEntryFromResult(result, "this-tab"));
    })
    .catch(err => showError(currentResultEl, err.message));
}

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs && tabs[0];
  if (!tab || !tab.url || !/^https?:\/\//.test(tab.url)) {
    currentUrlEl.textContent = "No scannable URL on this tab.";
    scanCurrentBtn.disabled = true;
    return;
  }
  activeTabUrl = tab.url;
  currentUrlEl.textContent = activeTabUrl;
  scanCurrentTab(); // auto-scan on popup open
});

scanCurrentBtn.addEventListener("click", scanCurrentTab);

// ---------- "Check URL" panel: manual paste-and-scan ----------
const manualUrlEl = document.getElementById("manualUrl");
const manualResultEl = document.getElementById("manualResult");
const manualScanBtn = document.getElementById("manualScanBtn");

function runManualScan() {
  const url = manualUrlEl.value.trim();
  if (!url) return;
  showLoading(manualResultEl);
  scanUrl(url)
    .then(result => {
      renderResult(manualResultEl, result);
      addToHistory(historyEntryFromResult(result, "manual"));
    })
    .catch(err => showError(manualResultEl, err.message));
}

manualScanBtn.addEventListener("click", runManualScan);
manualUrlEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") runManualScan();
});

// ---------- "Check Email" panel: upload and scan a .eml file ----------
async function scanEmail(file) {
  const formData = new FormData();
  formData.append("file", file, file.name);
  const resp = await fetch(`${API_BASE}/api/check-email`, {
    method: "POST",
    body: formData
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.error || `Request failed (${resp.status})`);
  return data;
}

function renderEmailResult(container, result) {
  const auth = result.auth_results || {};
  const notes = result.notes || [];
  const urlResults = result.url_results || [];

  let notesHtml = "";
  if (notes.length) {
    notesHtml = `<ul class="notes-list">${notes.map(n => `<li>${escapeHtml(n)}</li>`).join("")}</ul>`;
  } else {
    notesHtml = `<p class="hint" style="margin:4px 0;">No red flags found in headers, wording, or attachments.</p>`;
  }

  let urlsHtml = "";
  if (urlResults.length) {
    urlsHtml = urlResults.map(r => `
      <div class="url-mini-row">
        <span class="url-mini-link">${escapeHtml(r.url)}</span>
        <span class="verdict-badge ${verdictClass(r.verdict)}" style="margin:0;">${verdictIcon(r.verdict)} ${escapeHtml(r.verdict)}</span>
      </div>
    `).join("");
  } else {
    urlsHtml = `<p class="hint" style="margin:4px 0;">No links found in the email body.</p>`;
  }

  container.innerHTML = `
    <span class="verdict-badge ${verdictClass(result.verdict)}">
      ${verdictIcon(result.verdict)} ${escapeHtml(result.verdict)}
    </span>
    <table class="result-table">
      <tr><td class="label">Subject</td><td class="value">${escapeHtml(result.subject || "(no subject)")}</td></tr>
      <tr><td class="label">From</td><td class="value">${escapeHtml(result.sender || "(unknown)")}</td></tr>
      <tr><td class="label">SPF</td><td class="value">${escapeHtml(auth.spf || "none")}</td></tr>
      <tr><td class="label">DKIM</td><td class="value">${escapeHtml(auth.dkim || "none")}</td></tr>
      <tr><td class="label">DMARC</td><td class="value">${escapeHtml(auth.dmarc || "none")}</td></tr>
      <tr><td class="label">Risk score</td><td class="value"><strong>${result.score}</strong></td></tr>
    </table>
    <p class="hint" style="margin:10px 0 2px;"><strong>Flags</strong></p>
    ${notesHtml}
    <p class="hint" style="margin:10px 0 2px;"><strong>Embedded links (${urlResults.length})</strong></p>
    ${urlsHtml}
  `;
}

const emailFileEl = document.getElementById("emailFile");
const emailPickBtn = document.getElementById("emailPickBtn");
const emailFileNameEl = document.getElementById("emailFileName");
const emailScanBtn = document.getElementById("emailScanBtn");
const emailResultEl = document.getElementById("emailResult");
let selectedEmailFile = null;

emailPickBtn.addEventListener("click", () => emailFileEl.click());

emailFileEl.addEventListener("change", () => {
  const file = emailFileEl.files[0];
  if (!file) return;
  if (!file.name.toLowerCase().endsWith(".eml")) {
    showError(emailResultEl, "Please choose a .eml file.");
    emailScanBtn.disabled = true;
    return;
  }
  selectedEmailFile = file;
  emailFileNameEl.textContent = `${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
  emailFileNameEl.style.display = "block";
  emailScanBtn.disabled = false;
  emailResultEl.innerHTML = "";
});

emailScanBtn.addEventListener("click", () => {
  if (!selectedEmailFile) return;
  showLoading(emailResultEl);
  emailScanBtn.disabled = true;
  scanEmail(selectedEmailFile)
    .then(result => {
      renderEmailResult(emailResultEl, result);
      (result.url_results || []).forEach(r => {
        addToHistory({
          url: r.url,
          domain: r.domain || "",
          verdict: r.verdict,
          score: r.score,
          source: "email-link",
          time: Date.now()
        });
      });
    })
    .catch(err => showError(emailResultEl, err.message))
    .finally(() => { emailScanBtn.disabled = false; });
});

// ---------- "History" panel: every URL ShieldCheck has scanned ----------
const historyListEl = document.getElementById("historyList");
const clearHistoryBtn = document.getElementById("clearHistoryBtn");
const historyEmptyEl = document.getElementById("historyEmpty");

const SOURCE_LABELS = {
  "this-tab": "This Tab",
  "manual": "Check URL",
  "context-menu": "Right-click scan",
  "realtime-guard": "Auto-scanned (guard)",
  "email-link": "Email link"
};

function timeAgo(ts) {
  const diffMs = Date.now() - ts;
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function renderHistory(history) {
  if (!history.length) {
    historyListEl.innerHTML = "";
    historyEmptyEl.style.display = "block";
    clearHistoryBtn.style.display = "none";
    return;
  }
  historyEmptyEl.style.display = "none";
  clearHistoryBtn.style.display = "block";
  historyListEl.innerHTML = history.map(entry => `
    <div class="history-row">
      <div class="history-top">
        <span class="verdict-badge ${verdictClass(entry.verdict)}">${verdictIcon(entry.verdict)} ${escapeHtml(entry.verdict)}</span>
        <span class="history-time">${timeAgo(entry.time)}</span>
      </div>
      <div class="history-url">${escapeHtml(entry.url)}</div>
      <div class="history-meta">
        <span>${escapeHtml(SOURCE_LABELS[entry.source] || entry.source)}</span>
        <span>Score: ${entry.score}</span>
      </div>
    </div>
  `).join("");
}

function loadHistory() {
  chrome.storage.local.get({ scanHistory: [] }, (data) => {
    renderHistory(data.scanHistory);
  });
}

loadHistory();

// Keep the panel live if a background scan (real-time guard / context menu)
// writes new history while the popup happens to be open.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && "scanHistory" in changes) {
    renderHistory(changes.scanHistory.newValue || []);
  }
});

clearHistoryBtn.addEventListener("click", () => {
  chrome.storage.local.set({ scanHistory: [] });
});

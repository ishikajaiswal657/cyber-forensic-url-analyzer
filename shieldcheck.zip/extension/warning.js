const params = new URLSearchParams(location.search);
const targetUrl = params.get("url") || "";
const verdict = params.get("verdict") || "";
const score = params.get("score") || "";
const domain = params.get("domain") || "";

document.getElementById("fullUrl").textContent = targetUrl;
document.getElementById("domain").textContent = domain || "Unknown";
document.getElementById("score").textContent = score;

const badge = document.getElementById("verdictBadge");
const icon = document.getElementById("icon");
if (verdict === "HIGH RISK / PHISHING LIKELY") {
  badge.textContent = "🚨 HIGH RISK / PHISHING LIKELY";
  badge.className = "verdict-badge verdict-risk";
  icon.textContent = "🚨";
} else {
  badge.textContent = "⚠️ SUSPICIOUS";
  badge.className = "verdict-badge verdict-suspicious";
  icon.textContent = "⚠️";
}

document.getElementById("backBtn").addEventListener("click", () => {
  if (history.length > 1) {
    history.back();
  } else {
    location.href = "https://www.google.com";
  }
});

document.getElementById("continueBtn").addEventListener("click", () => {
  if (!targetUrl) return;
  chrome.runtime.sendMessage({ type: "shieldcheck-allow-and-navigate", url: targetUrl });
});
